package com.model;

import java.util.Scanner;

import org.springframework.stereotype.Component;
@Component
public class QuestionDAOImpl implements QuestionDAO {

	@Override
	public void takeTest(Question[] questions) {
		int score=0;
		Scanner s=new Scanner(System.in);
		for(int i=0;i<questions.length;i++)
		{
			System.out.println(questions[i].prompt);
			String ans=s.nextLine();
			if(ans.equals(questions[i].answer))
			{
				score++;
			}
		}
		System.out.println("your score"+score+"/"+questions.length);
		// TODO Auto-generated method stub

	}

}
