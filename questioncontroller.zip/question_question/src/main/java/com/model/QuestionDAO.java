package com.model;

import org.springframework.stereotype.Component;

@Component
public interface QuestionDAO {
	
	public void takeTest(Question[] questions);
	

}
