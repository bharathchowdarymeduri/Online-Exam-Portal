package com.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuestionService {
	
	
	@Autowired
	QuestionDAO questionDAOImpl;
	
	   public void save(Question question)
	   {
		   String q1= "What color are apples?\n"
					 +"(a)red/green\n(b)orange\n(c)magneta\n";
			
			Question[] questions= {new Question(q1,"a")};
			
		   questionDAOImpl.takeTest(questions);
	   }

}
